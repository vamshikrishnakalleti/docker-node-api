const { expect } = require('chai')

describe('Test install', () => {
    it('should pass', () => {
        expect(true).equal(true)
    })
})
